class Purchase {
    protected double amaount=12000.00;
}
class Payment extends Purchase {
    private String payment_ways="a) BANK b)CASH c)OTHER PAYMENT-WAYS";
    private String payment_ID="KT-RT-342";
    public void metod1() {
        System.out.println("price of one book "+amount);
        System.out.println("ways of payment are "+payment_ways);
        System.out.println("payment ID is "+payment_ID);
    }
}
class Price extends Payment {
    private String information="OUR PRICE ARE FRIENDS TO YOUR DEAR CUSTOMER PLEASE SAVED BY US";
    public void method2() {
        System.out.println("read here "+information);
    }
}
class Main {
    public static void main(Sring[] args) {
        Price pay=new Price();
        Price prc=new Price();
        pay.method1();
        prc.method2();
    }
}