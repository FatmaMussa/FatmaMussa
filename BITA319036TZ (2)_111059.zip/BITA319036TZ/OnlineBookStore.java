class OnlineBookStore {
    protected int book_number=500;
}
class Store extends OnlineBookStore {
    private String store_name="KITUU STORE";
    private String store_id="KT837";
    public void methods() {
        System.out.println("books found in store are "+book_number);
        System.out.println("store name is "+store_name);
        System.out.println("sore ID is "+store_id);
    }
}
class Main {
    public static void main(String[] args) {
        Store book=new Store();
        book.methods();
    }
}