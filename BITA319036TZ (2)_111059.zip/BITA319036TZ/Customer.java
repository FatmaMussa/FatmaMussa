import java.util.Scanner;
public class Customer {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("NAME OF CUSTOMER");
        String name=sc.nextLine();
        System.out.println("ADRESS OF CUSTOMER");
        String adress=sc.nextLine();
        System.out.println("ENTER NAME OF BOOK");
        String name_book=sc.nextLine();
        System.out.println("name of customer is "+name+" adree of customer is "+adress+" and the name of book purchased is "+name_book);
    }
}